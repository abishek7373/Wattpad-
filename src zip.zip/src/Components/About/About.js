import React from 'react'
import UserList from '../Lab_files/UserList'
const About = () => {
    return (
        <div>
            <h1>
                <center>
                    About
                    <div style={{marginTop:'60px'}}>
                        <UserList />
                    </div>
                </center>
            </h1>
        </div>
    )
}

export default About