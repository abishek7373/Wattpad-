import React from 'react'

const HelloWorld = () => {
  return (
    <div>
        <h1>HelloWorld</h1>
    </div>
  )
}

export default HelloWorld