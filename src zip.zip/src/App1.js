import React from 'react'
import UserList from './Components/Lab_files/UserList'
const App1 = () => {
  return (
    <div>
      <UserList />
    </div>
  )
}

export default App1